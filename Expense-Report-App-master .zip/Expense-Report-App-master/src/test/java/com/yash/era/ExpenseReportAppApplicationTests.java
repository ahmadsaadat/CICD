package com.yash.era;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseReportAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
