package com.yash.era;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenseReportAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpenseReportAppApplication.class, args);
	}

}
